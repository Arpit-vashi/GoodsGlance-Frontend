<?php
        header("Location: https://keyauthdocs.apidog.io");
        exit();
