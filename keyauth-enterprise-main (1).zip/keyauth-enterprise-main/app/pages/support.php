

<style>
        div.scroll {
                width: 1000px;
                height: 330px;
                overflow-x: hidden;
                overflow-y: auto;
        }
</style>
<!--begin::Container-->
<div id="kt_content_container" class="container-xxl">
        <div class="card mb-xl-8">
                <div class="card-header border-0 pt-5">
                        <h3 class="card-title align-items-start flex-column">
                                <span class="card-label fw-bolder fs-3 mb-1">Support Chat</span>
                        </h3>
                </div>
                <div class="card-body py-3">
                        Web tickets have been discontinued - Please use the chat box on the bottom right of the website.
                </div>
        </div>
</div>