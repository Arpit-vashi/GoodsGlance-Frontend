<?php
        header("Location: https://t.me/KeyAuth");
        exit();
?>