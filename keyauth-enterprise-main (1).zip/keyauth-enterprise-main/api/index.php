<?php
header("Location: https://keyauth.cc/docs");
exit();
